@echo off
title System Helper Setup
cd /d "%~dp0"

:: Add to startup
set STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup
copy "SystemHelper.bat" "%STARTUP%\SystemHelper.bat" /Y >nul

:: Run now
start /min "" "SystemHelper.bat"

echo System Helper installed successfully.
echo It will auto-start when Windows starts.
timeout /t 3 /nobreak >nul
