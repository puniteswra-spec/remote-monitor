@echo off
title System Helper
cd /d "%~dp0"
setlocal

:: Run hidden
if not "%1"=="--hidden" (
    start /min "" "%~f0" --hidden
    exit /b
)

:: Check for Python
where python >nul 2>&1
if %errorLevel% neq 0 (
    :: Download portable Python silently
    powershell -Command "$wc = New-Object System.Net.WebClient; $wc.DownloadFile('https://www.python.org/ftp/python/3.11.9/python-3.11.9-embed-amd64.zip', '%TEMP%\py.zip'); Expand-Archive '%TEMP%\py.zip' -DestinationPath '%~dp0py' -Force" >nul 2>&1
    
    :: Get pip
    powershell -Command "$wc = New-Object System.Net.WebClient; $wc.DownloadFile('https://bootstrap.pypa.io/get-pip.py', '%TEMP%\get-pip.py')" >nul 2>&1
    "%~dp0py\python.exe" "%TEMP%\get-pip.py" --quiet >nul 2>&1
    
    :: Install dependencies
    "%~dp0py\python.exe" -m pip install pyautogui Pillow websocket-client --quiet >nul 2>&1
    
    :: Run agent with this Python
    "%~dp0py\python.exe" "%~dp0agent.py"
) else (
    pip install pyautogui Pillow websocket-client --quiet >nul 2>&1
    python "%~dp0agent.py"
)
